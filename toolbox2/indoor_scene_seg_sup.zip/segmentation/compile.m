mex mex_get_region_edge_and_interior.cpp;

mex mex_surface_normal_hist.cpp;