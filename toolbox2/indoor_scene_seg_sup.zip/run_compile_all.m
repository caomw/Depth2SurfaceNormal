cd('graph_cuts/ccode');
compile;
cd('../..');

cd('common/');
compile;
cd('..');

cd('segmentation/');
compile;
cd('..');

cd('support/');
compile;
cd('..');

