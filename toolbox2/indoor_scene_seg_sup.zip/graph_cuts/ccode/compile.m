mex mex_graphCut.cpp graph.cpp dummy.cpp
mex mex_graphCut_fillPlane.cpp graph.cpp dummy.cpp
