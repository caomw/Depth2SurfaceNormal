% Adds prerequisite paths.
addpath('~/workspace/matlab_commons/datasets/');
addpath('~/workspace/matlab_commons/time/');
